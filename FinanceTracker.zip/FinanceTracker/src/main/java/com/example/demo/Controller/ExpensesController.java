package com.example.demo.Controller;

import com.example.demo.Entity.Expense;
import com.example.demo.Entity.User;
import com.example.demo.Service.ExpenseService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/expenses")
public class ExpensesController {

    @Autowired
    private ExpenseService expenseService;

    // Show form for adding EMI expense
    @GetMapping("/emi")
    public String showEmiForm(HttpSession session, Model model) {
        User loggedInUser = (User) session.getAttribute("loggedInUser");
        if (loggedInUser == null) {
            return "redirect:/login";
        }
        model.addAttribute("expense", new Expense());
        return "emiForm";  // HTML page for EMI expense input
    }

    // Handle EMI expense form submission
    @PostMapping("/emi/add")
    public String addEmiExpense(@ModelAttribute("expense") Expense expense, HttpSession session) {
        User loggedInUser = (User) session.getAttribute("loggedInUser");
        if (loggedInUser == null) {
            return "redirect:/login";
        }
        expense.setUser(loggedInUser);
        expense.setType("EMI");
        expenseService.saveExpense(expense);
        return "redirect:/dashboard";
    }
}
