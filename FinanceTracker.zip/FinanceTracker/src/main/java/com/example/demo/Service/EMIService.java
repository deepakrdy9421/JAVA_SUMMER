package com.example.demo.Service;

import com.example.demo.Entity.EMI;
import java.util.List;

public interface EMIService {
    void saveEMI(EMI emi);
    List<EMI> getAllEMIs();
    EMI getEMIById(Long id);
    void deleteEMI(Long id);
}
