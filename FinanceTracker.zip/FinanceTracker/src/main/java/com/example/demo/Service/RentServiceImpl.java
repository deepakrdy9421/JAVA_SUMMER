package com.example.demo.Service;

import com.example.demo.Entity.Rent;
import com.example.demo.Repository.RentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RentServiceImpl implements RentService {

    @Autowired
    private RentRepository rentRepository;

    @Override
    public void saveRent(Rent rent) {
        rentRepository.save(rent);
    }

    @Override
    public List<Rent> getAllRents() {
        return rentRepository.findAll();
    }

    @Override
    public Rent getRentById(Long id) {
        return rentRepository.findById(id).orElse(null);
    }

    @Override
    public void deleteRentById(Long id) {
        rentRepository.deleteById(id);
    }
}
