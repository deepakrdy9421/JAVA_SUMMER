package com.example.demo.Controller;

import com.example.demo.Entity.EMI;
import com.example.demo.Service.EMIService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/emi")
public class EMIController {

    @Autowired
    private EMIService emiService;

    @GetMapping
    public String showEMIPage(Model model) {
        model.addAttribute("emiList", emiService.getAllEMIs());
        model.addAttribute("emi", new EMI());
        return "emi";
    }

    @PostMapping("/add")
    public String addEMI(@ModelAttribute EMI emi) {
        emiService.saveEMI(emi);
        return "redirect:/emi";
    }

    @GetMapping("/edit/{id}")
    public String editEMI(@PathVariable Long id, Model model) {
        EMI emi = emiService.getEMIById(id);
        model.addAttribute("emi", emi);
        model.addAttribute("emiList", emiService.getAllEMIs());
        return "emi";
    }

    @PostMapping("/update/{id}")
    public String updateEMI(@PathVariable Long id, @ModelAttribute EMI updatedEMI) {
        EMI emi = emiService.getEMIById(id);
        if (emi != null) {
            emi.setAmount(updatedEMI.getAmount());
            emi.setPurpose(updatedEMI.getPurpose());
            emi.setDueDate(updatedEMI.getDueDate());
            emiService.saveEMI(emi);
        }
        return "redirect:/emi";
    }

    @GetMapping("/delete/{id}")
    public String deleteEMI(@PathVariable Long id) {
        emiService.deleteEMI(id);
        return "redirect:/emi";
    }
}
