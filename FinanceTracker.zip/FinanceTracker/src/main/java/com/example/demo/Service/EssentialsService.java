package com.example.demo.Service;

import com.example.demo.Entity.Essentials;
import java.util.List;

public interface EssentialsService {
    List<Essentials> getAllEssentials();

	void deleteEssential(Long id);

	Object getEssentialById(Long id);

	void saveEssential(Essentials essential);
}
