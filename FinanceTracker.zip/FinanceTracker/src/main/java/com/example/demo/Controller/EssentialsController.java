package com.example.demo.Controller;

import com.example.demo.Entity.Essentials;
import com.example.demo.Service.EssentialsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/essentials")
public class EssentialsController {

    @Autowired
    private EssentialsService essentialsService;

    @GetMapping
    public String viewEssentialsPage(Model model) {
        model.addAttribute("essential", new Essentials());
        model.addAttribute("essentialsList", essentialsService.getAllEssentials());
        return "essentials";
    }

    @PostMapping("/save")
    public String saveEssential(@ModelAttribute Essentials essential) {
        essentialsService.saveEssential(essential);
        return "redirect:/essentials";
    }

    @GetMapping("/edit/{id}")
    public String editEssential(@PathVariable Long id, Model model) {
        model.addAttribute("essential", essentialsService.getEssentialById(id));
        model.addAttribute("essentialsList", essentialsService.getAllEssentials());
        return "essentials";
    }

    @GetMapping("/delete/{id}")
    public String deleteEssential(@PathVariable Long id) {
        essentialsService.deleteEssential(id);
        return "redirect:/essentials";
    }
}
