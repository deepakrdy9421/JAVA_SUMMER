package com.example.demo.Service;

import com.example.demo.Entity.Rent;

import java.util.List;

public interface RentService {
    void saveRent(Rent rent);
    List<Rent> getAllRents();
    Rent getRentById(Long id);
    void deleteRentById(Long id);
}
