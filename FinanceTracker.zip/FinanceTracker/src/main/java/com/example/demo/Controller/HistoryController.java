package com.example.demo.Controller;

import com.example.demo.Entity.EMI;
import com.example.demo.Entity.Rent;
import com.example.demo.Entity.Essentials;
import com.example.demo.Service.EMIService;
import com.example.demo.Service.RentService;
import com.example.demo.Service.EssentialsService; // Make sure you have this service

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class HistoryController {

    @Autowired
    private EMIService emiService;

    @Autowired
    private RentService rentService;

    @Autowired
    private EssentialsService essentialsService;

    @GetMapping("/history")
    public String viewHistory(Model model) {
        List<EMI> emiList = emiService.getAllEMIs();
        List<Rent> rentList = rentService.getAllRents();
        List<Essentials> essentialList = essentialsService.getAllEssentials();

        model.addAttribute("emiList", emiList);
        model.addAttribute("rentList", rentList);
        model.addAttribute("essentialList", essentialList);

        return "history";
    }
}
