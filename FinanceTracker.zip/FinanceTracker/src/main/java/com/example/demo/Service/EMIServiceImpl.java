package com.example.demo.Service;

import com.example.demo.Entity.EMI;
import com.example.demo.Repository.EMIRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EMIServiceImpl implements EMIService {

    @Autowired
    private EMIRepository emiRepository;

    @Override
    public void saveEMI(EMI emi) {
        emiRepository.save(emi);
    }

    @Override
    public List<EMI> getAllEMIs() {
        return emiRepository.findAll();
    }

    @Override
    public EMI getEMIById(Long id) {
        return emiRepository.findById(id).orElse(null);
    }

    @Override
    public void deleteEMI(Long id) {
        emiRepository.deleteById(id);
    }
}
