package com.example.demo.Controller;

import com.example.demo.Entity.Rent;
import com.example.demo.Service.RentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class RentController {

    @Autowired
    private RentService rentService;

    @GetMapping("/rent")
    public String showRentForm(Model model) {
        model.addAttribute("rents", rentService.getAllRents());
        model.addAttribute("rent", new Rent());
        return "rent";
    }

    @PostMapping("/rent/save")
    public String saveRent(@ModelAttribute Rent rent) {
        rent.setTotalAmount(rent.getAmount() + rent.getExtraCharges());
        rentService.saveRent(rent);
        return "redirect:/rent";
    }

    @GetMapping("/rent/edit/{id}")
    public String editRent(@PathVariable Long id, Model model) {
        Rent rent = rentService.getRentById(id);
        model.addAttribute("rent", rent);
        model.addAttribute("rents", rentService.getAllRents());
        return "rent";
    }

    @GetMapping("/rent/delete/{id}")
    public String deleteRent(@PathVariable Long id) {
        rentService.deleteRentById(id);
        return "redirect:/rent";
    }
}
