package com.example.demo.Repository;

import com.example.demo.Entity.Essentials;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EssentialsRepository extends JpaRepository<Essentials, Long> {
}
