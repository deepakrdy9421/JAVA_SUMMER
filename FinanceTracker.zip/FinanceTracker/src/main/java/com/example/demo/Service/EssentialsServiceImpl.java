package com.example.demo.Service;

import com.example.demo.Entity.Essentials;
import com.example.demo.Repository.EssentialsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EssentialsServiceImpl implements EssentialsService {

    @Autowired
    private EssentialsRepository essentialsRepository;

    @Override
    public List<Essentials> getAllEssentials() {
        return essentialsRepository.findAll();
    }

	@Override
	public void deleteEssential(Long id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Object getEssentialById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveEssential(Essentials essential) {
		// TODO Auto-generated method stub
		
	}
}
